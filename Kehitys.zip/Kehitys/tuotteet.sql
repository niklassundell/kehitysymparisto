-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: magnesium:3306
-- Generation Time: Oct 23, 2018 at 11:46 AM
-- Server version: 5.6.15-log
-- PHP Version: 5.5.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------

--
-- Table structure for table `tuotteet`
--

CREATE TABLE IF NOT EXISTS `tuotteet` (
  `Tuoteid` int(2) NOT NULL DEFAULT '0',
  `Tuotenimi` varchar(33) DEFAULT NULL,
  `Toimittaja` varchar(46) DEFAULT NULL,
  `Ryhma` varchar(16) DEFAULT NULL,
  `Maara` varchar(20) DEFAULT NULL,
  `Yksikkohinta` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`Tuoteid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tuotteet`
--

INSERT INTO `tuotteet` (`Tuoteid`, `Tuotenimi`, `Toimittaja`, `Ryhma`, `Maara`, `Yksikkohinta`) VALUES
(1, 'Chai', 'Exotic Liquids', 'Juomat', '10 pakk. x 20 pussia', '77.40 '),
(2, 'Chang', 'Exotic Liquids', 'Juomat', '24 x 12 oz pullo', '81.70 '),
(3, 'Aniseed Syrup', 'Exotic Liquids', 'Mausteet', '12 x 550 ml pullo', '43.00 '),
(4, 'Chef Antons Cajun Seasoning', 'New Orleans Cajun Delights', 'Mausteet', '48 x 6 oz tölkki', '94.60 '),
(5, 'Chef Antons Gumbo Mix', 'New Orleans Cajun Delights', 'Mausteet', '36 pakkausta', '91.81 '),
(6, 'Grandmas Boysenberry Spread', 'Grandma Kellys Homestead', 'Mausteet', '12 x 8 oz tölkki', '107.50 '),
(7, 'Uncle Bobs Organic Dried Pears', 'Grandma Kellys Homestead', 'Jalosteet', '12 x 1 lb pakk.', '129.00 '),
(8, 'Northwoods Cranberry Sauce', 'Grandma Kellys Homestead', 'Mausteet', '12 x 12 oz tölkki', '172.00 '),
(9, 'Mishi Kobe Niku', 'Tokyo Traders', 'Lihatuotteet', '18 x 500 g pakk.', '417.10 '),
(10, 'Ikura', 'Tokyo Traders', 'Kalatuotteet', '12 x 200 ml tölkki', '133.30 '),
(11, 'Queso Cabrales', 'Cooperativa de Quesos Las Cabras', 'Maitotuotteet', '1 kg pakk.', '90.30 '),
(12, 'Queso Manchego La Pastora', 'Cooperativa de Quesos Las Cabras', 'Maitotuotteet', '10 x 500 g pakk.', '163.40 '),
(13, 'Konbu', 'Mayumis', 'Kalatuotteet', '2 kg paketti', '25.80 '),
(14, 'Tofu', 'Mayumis', 'Jalosteet', '40 x 100 g pakk.', '99.98 '),
(15, 'Genen Shouyu', 'Mayumis', 'Mausteet', '24 x 250 ml pullo', '66.65 '),
(16, 'Pavlova', 'Pavlova. Ltd.', 'Makeiset', '32 x 500 g paketti', '75.04 '),
(17, 'Alice Mutton', 'Pavlova. Ltd.', 'Lihatuotteet', '20 x 1 kg tölkki', '167.70 '),
(18, 'Carnarvon Tigers', 'Pavlova. Ltd.', 'Kalatuotteet', '16 kg pakk.', '268.75 '),
(19, 'Teatime Chocolate Biscuits', 'Specialty Biscuits. Ltd.', 'Makeiset', '10 ras. x 12 kpl.', '39.56 '),
(20, 'Sir Rodneys Marmalade', 'Specialty Biscuits. Ltd.', 'Makeiset', '30 lahjapakkausta', '348.30 '),
(21, 'Sir Rodneys Scones', 'Specialty Biscuits. Ltd.', 'Makeiset', '24 pakk. x 4 kpl.', '43.00 '),
(22, 'Gustafs Knäckebröd', 'PB Knäckebröd AB', 'Viljatuotteet', '24 x 500 g pakk.', '90.30 '),
(23, 'Tunnbröd', 'PB Knäckebröd AB', 'Viljatuotteet', '12 x 250 g pakk.', '38.70 '),
(24, 'Guaran  Fant stica', 'Refrescos Americanas LTDA', 'Juomat', '12 x 355 ml tölkki', '19.35 '),
(25, 'NuNuCa Nuá-Nougat-Creme', 'Heli Süáwaren GmbH & Co. KG', 'Makeiset', '20 x 450 g astia', '60.20 '),
(26, 'Gumbär Gummibärchen', 'Heli Süáwaren GmbH & Co. KG', 'Makeiset', '100 x 250 g pussi', '134.29 '),
(27, 'Schoggi Schokolade', 'Heli Süáwaren GmbH & Co. KG', 'Makeiset', '100 x 100 g pala', '188.77 '),
(28, 'Rössle Sauerkraut', 'Plutzer Lebensmittelgroámärkte AG', 'Jalosteet', '25 x 825 g cans', '196.08 '),
(29, 'Thringer Rostbratwurst', 'Plutzer Lebensmittelgroámärkte AG', 'Lihatuotteet', '50 pakk. x 30 makk.', '532.30 '),
(30, 'Nord-Ost Matjeshering', 'Nord-Ost-Fisch Handelsgesellschaft mbH', 'Kalatuotteet', '10 x 200 g astia', '111.33 '),
(31, 'Gorgonzola Telino', 'Formaggi Fortini s.r.l.', 'Maitotuotteet', '12 x 100 g pakk.', '53.75 '),
(32, 'Mascarpone Fabioli', 'Formaggi Fortini s.r.l.', 'Maitotuotteet', '24 x 200 g pakk.', '137.60 '),
(33, 'Geitost', 'Norske Meierier', 'Maitotuotteet', '500 g', '10.75 '),
(34, 'Sasquatch Ale', 'Bigfoot Breweries', 'Juomat', '24 x 12 oz pullo', '60.20 '),
(35, 'Steeleye Stout', 'Bigfoot Breweries', 'Juomat', '24 x 12 oz pullo', '77.40 '),
(36, 'Inlagd Sill', 'Svensk Sjöföda AB', 'Kalatuotteet', '24 x 250 g  tölkki', '81.70 '),
(37, 'Gravad lax', 'Svensk Sjöföda AB', 'Kalatuotteet', '12 x 500 g pakk.', '111.80 '),
(38, 'Cóte de Blaye', 'Aux joyeux ecclésiastiques', 'Juomat', '12 x 75 cl pullo', '1 133.05 '),
(39, 'Chartreuse verte', 'Aux joyeux ecclésiastiques', 'Juomat', '750 cc pullo', '77.40 '),
(40, 'Boston Crab Meat', 'New England Seafood Cannery', 'Kalatuotteet', '24 x 4 oz tölkki', '79.12 '),
(41, 'Jacks New England Clam Chowder', 'New England Seafood Cannery', 'Kalatuotteet', '12 x 12 oz tölkki', '41.50 '),
(42, 'Singaporean Hokkien Fried Mee', 'Leka Trading', 'Viljatuotteet', '32 x 1 kg pakk.', '60.20 '),
(43, 'Ipoh Coffee', 'Leka Trading', 'Juomat', '16 x 500 g tölkki', '197.80 '),
(44, 'Gula Malacca', 'Leka Trading', 'Mausteet', '20 x 2 kg pussi', '83.64 '),
(45, 'Rgede sild', 'Lyngbysild', 'Kalatuotteet', '1 kg pakk.', '40.85 '),
(46, 'Spegesild', 'Lyngbysild', 'Kalatuotteet', '4 x 450 g astia', '51.60 '),
(47, 'Zaanse koeken', 'Zaanse Snoepfabriek', 'Makeiset', '10 x 4 oz rasia', '40.85 '),
(48, 'Chocolade', 'Zaanse Snoepfabriek', 'Makeiset', '10 pakk.', '54.83 '),
(49, 'Maxilaku', 'Karkki Oy', 'Makeiset', '24 x 50 g pakk.', '86.00 '),
(50, 'Valkoinen suklaa', 'Karkki Oy', 'Makeiset', '12 x 100 g tanko', '69.88 '),
(51, 'Manjimup Dried Apples', 'Gday. Mate', 'Jalosteet', '50 x 300 g pakk.', '227.90 '),
(52, 'Filo Mix', 'Gday. Mate', 'Viljatuotteet', '16 x 2 kg pakk.', '30.10 '),
(53, 'Perth Pasties', 'Gday. Mate', 'Lihatuotteet', '48 palaa', '141.04 '),
(54, 'Tourtióre', 'Ma Maison', 'Lihatuotteet', '16 palaa', '32.04 '),
(55, 'Pété chinois', 'Ma Maison', 'Lihatuotteet', '24 pakk. x 2 palaa', '103.20 '),
(56, 'Gnocchi di nonna Alice', 'Pasta Buttini s.r.l.', 'Viljatuotteet', '24 x 250 g pakk.', '163.40 '),
(57, 'Ravioli Angelo', 'Pasta Buttini s.r.l.', 'Viljatuotteet', '24 x 250 g pakk.', '83.85 '),
(58, 'Escargots de Bourgogne', 'Escargots Nouveaux', 'Kalatuotteet', '24 palaa', '56.98 '),
(59, 'Raclette Courdavault', 'Gai péturage', 'Maitotuotteet', '5 kg pakk.', '236.50 '),
(60, 'Camembert Pierrot', 'Gai péturage', 'Maitotuotteet', '15 x 300 g pakk.', '146.20 '),
(61, 'Sirop dórable', 'Foréts dórables', 'Mausteet', '24 x 500 ml pullo', '122.55 '),
(62, 'Tarte au sucre', 'Foréts dórables', 'Makeiset', '48 palaa', '211.99 '),
(63, 'Vegie-spread', 'Pavlova. Ltd.', 'Mausteet', '15 x 625 g tölkki', '188.77 '),
(64, 'Wimmers gute Semmelknödel', 'Plutzer Lebensmittelgroámärkte AG', 'Viljatuotteet', '20 puss. x 4 palaa', '142.98 '),
(65, 'Louisiana Fiery Hot Pepper Sauce', 'New Orleans Cajun Delights', 'Mausteet', '32 x 8 oz pullo', '90.52 '),
(66, 'Louisiana Hot Spiced Okra', 'New Orleans Cajun Delights', 'Mausteet', '24 x 8 oz tölkki', '73.10 '),
(67, 'Laughing Lumberjack Lager', 'Bigfoot Breweries', 'Juomat', '24 x 12 oz pullo', '60.20 '),
(68, 'Scottish Longbreads', 'Specialty Biscuits. Ltd.', 'Makeiset', '10 pakk. x 8 palaa', '53.75 '),
(69, 'Gudbrandsdalsost', 'Norske Meierier', 'Maitotuotteet', '10 kg pakk.', '154.80 '),
(70, 'Outback Lager', 'Pavlova. Ltd.', 'Juomat', '24 x 355 ml pullo', '64.50 '),
(71, 'Fltemysost', 'Norske Meierier', 'Maitotuotteet', '10 x 500 g pakk.', '92.45 '),
(72, 'Mozzarella di Giovanni', 'Formaggi Fortini s.r.l.', 'Maitotuotteet', '24 x 200 g pakk.', '149.64 '),
(73, 'Röd Kaviar', 'Svensk Sjöföda AB', 'Kalatuotteet', '24 x 150 g tölkki', '64.50 '),
(74, 'Longlife Tofu', 'Tokyo Traders', 'Jalosteet', '5 kg pakk.', '43.00 '),
(75, 'Rhönbräu Klosterbier', 'Plutzer Lebensmittelgroámärkte AG', 'Juomat', '24 x 0.5 l pullo', '33.33 '),
(76, 'Lakkalikööri', 'Karkki Oy', 'Juomat', '500 ml', '77.40 '),
(77, 'Original Frankfurter grüne Soáe', 'Plutzer Lebensmittelgroámärkte AG', 'Mausteet', '12 pakk.', '55.90 ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;