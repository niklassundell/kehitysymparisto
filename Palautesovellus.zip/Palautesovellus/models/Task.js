var db = require('../lib/dbconn'); //reference of dbconnection.js 

var Task = { 
    getAllTasks: function(callback) { 
    return db.query("select * from palautteet", callback); 
  }, 
  getTaskById: function(id, callback) { 
    return db.query("select * from palautteet where id=?", [id], callback); 
  }, 
  addTask: function(Task, callback) { 
    return db.query("insert into palautteet (id,title,text) values(NULL,?,?)", [ Task.title, Task.status], callback); 
  }, 
  deleteTask: function(id, callback) { 
    return db.query("delete from palautteet where id=?", [id], callback); 
  }, 
  updateTask: function(id, Task, callback) { 
    return db.query("update palautteet set title=?,status=? where id=?", [Task.title, Task.status, id], callback); 
  } 
};

module.exports = Task;