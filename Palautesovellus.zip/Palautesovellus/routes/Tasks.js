var express = require('express'); 
var router = express.Router(); 

var Task = require('../models/Task'); 
var task_controller = require('../controllers/taskController');

function isAuthenticated(req, res, next) {
  if (req.session.user)
      return next();
  res.redirect('/signin');
}

router.get('/',isAuthenticated, task_controller.task_list);    
router.get('/Addtask', isAuthenticated, task_controller.task_create_get);
router.post('/Addtask',isAuthenticated, task_controller.task_create_post);    
router.get('/:id', isAuthenticated,task_controller.task_details);
router.get('/deletetask/:id', isAuthenticated, task_controller.task_delete_get);    
router.get('/updatetask/:id', isAuthenticated, task_controller.task_update_get);    
router.post('/updatetask/:id', isAuthenticated, task_controller.task_update_post);    

module.exports = router;